import React, { Component } from 'react';

class Orders extends Component {
    render() {
        return (
            <div className="container-fluid">
                <div className="row">
                        Orders Tab - Working
                </div>
            </div>
        );
    }
}

export default Orders;