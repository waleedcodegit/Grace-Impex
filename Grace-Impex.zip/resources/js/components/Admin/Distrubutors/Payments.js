import React, { Component } from 'react';

class Payments extends Component {
    render() {
        return (
            <div className="container-fluid">
                Payments Tab - Working
            </div>
        );
    }
}

export default Payments;