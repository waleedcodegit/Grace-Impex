module.exports = {
    baseurl:'',
    img_baseurl:'/images/'
}